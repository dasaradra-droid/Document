using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace AssignmentPortal.Backend.Models
{
    public class Assignment
    {
        public int Id { get; set; }
        [Required]
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime Deadline { get; set; }
        public int TeacherId { get; set; }
        public User Teacher { get; set; }
    }
}
