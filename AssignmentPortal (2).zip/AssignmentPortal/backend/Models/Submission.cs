using System;
using System.ComponentModel.DataAnnotations;

namespace AssignmentPortal.Backend.Models
{
    public class Submission
    {
        public int Id { get; set; }
        public int AssignmentId { get; set; }
        public Assignment Assignment { get; set; }
        public int StudentId { get; set; }
        public User Student { get; set; }
        public string FileUrl { get; set; } // S3 URL
        public DateTime SubmittedAt { get; set; } = DateTime.UtcNow;
        public string Status { get; set; } = "Submitted"; // Submitted, Reviewed, Rejected
        public string? Grade { get; set; } // A-E
        public string? Remarks { get; set; }
    }
}
