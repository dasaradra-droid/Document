using AssignmentPortal.Backend.Data;
using AssignmentPortal.Backend.DTOs;
using AssignmentPortal.Backend.Models;
using AssignmentPortal.Backend.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;
using System.Security.Claims;

namespace AssignmentPortal.Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class SubmissionController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly IS3Service _s3Service;

        public SubmissionController(AppDbContext context, IS3Service s3Service)
        {
            _context = context;
            _s3Service = s3Service;
        }

        [HttpPost("{assignmentId}")]
        [Authorize(Roles = "Student")]
        public async Task<IActionResult> SubmitAssignment(int assignmentId, IFormFile file)
        {
            if (file == null || file.Length == 0)
                return BadRequest("No file uploaded.");

            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);

            // Check if already submitted
            var existing = await _context.Submissions
                .FirstOrDefaultAsync(s => s.AssignmentId == assignmentId && s.StudentId == userId);

            if (existing != null)
                return BadRequest("You have already submitted this assignment.");

            // Upload to S3
            using var stream = file.OpenReadStream();
            var fileKey = await _s3Service.UploadFileAsync(stream, file.FileName);

            var submission = new Submission
            {
                AssignmentId = assignmentId,
                StudentId = userId,
                FileUrl = fileKey, // Storing Key as URL for now, will generate signed URL on retrieve
                Status = "Submitted"
            };

            _context.Submissions.Add(submission);
            await _context.SaveChangesAsync();

            // Notify Teacher
            var assignment = await _context.Assignments.FindAsync(assignmentId);
            if (assignment != null)
            {
                var studentName = User.Identity.Name ?? (await _context.Users.FindAsync(userId))?.Username ?? "Unknown Student";

                _context.Notifications.Add(new Notification
                {
                    UserId = assignment.TeacherId,
                    Message = $"Submission received for assignment: {assignment.Title} from {studentName}",
                    CreatedAt = DateTime.UtcNow
                });
                await _context.SaveChangesAsync();
            }


            return Ok("Assignment submitted successfully.");
        }

        [HttpGet("assignment/{assignmentId}")]
        [Authorize(Roles = "Teacher")]
        public async Task<ActionResult<IEnumerable<SubmissionDto>>> GetSubmissionsForAssignment(int assignmentId)
        {
            var submissions = await _context.Submissions
                .Include(s => s.Student)
                .Where(s => s.AssignmentId == assignmentId)
                .Select(s => new SubmissionDto
                {
                    Id = s.Id,
                    AssignmentId = s.AssignmentId,
                    StudentName = s.Student.Username,
                    FileUrl = s.FileUrl, 
                    SubmittedAt = s.SubmittedAt,
                    Status = s.Status,
                    Grade = s.Grade,
                    Remarks = s.Remarks
                })
                .ToListAsync();

            // Generate Pre-signed URLs
            foreach (var sub in submissions)
            {
                sub.FileUrl = _s3Service.GeneratePreSignedURL(sub.FileUrl);
            }

            return Ok(submissions);
        }
        
        [HttpGet("my-submissions")]
        [Authorize(Roles = "Student")]
        public async Task<ActionResult<IEnumerable<SubmissionDto>>> GetMySubmissions()
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);
            var submissions = await _context.Submissions
                .Include(s => s.Student)
                .Where(s => s.StudentId == userId)
                .Select(s => new SubmissionDto
                {
                    Id = s.Id,
                    AssignmentId = s.AssignmentId,
                    StudentName = s.Student.Username,
                    FileUrl = s.FileUrl,
                    SubmittedAt = s.SubmittedAt,
                    Status = s.Status,
                    Grade = s.Grade,
                    Remarks = s.Remarks
                })
                .ToListAsync();
            
             foreach (var sub in submissions)
            {
                sub.FileUrl = _s3Service.GeneratePreSignedURL(sub.FileUrl);
            }

            return Ok(submissions);
        }

        [HttpPost("{id}/grade")]
        [Authorize(Roles = "Teacher")]
        public async Task<IActionResult> GradeSubmission(int id, GradeSubmissionDto request)
        {
            var submission = await _context.Submissions.FindAsync(id);
            if (submission == null) return NotFound();

            if (request.Rejected)
            {
                submission.Status = "Rejected";
                submission.Grade = null;
            }
            else
            {
                submission.Status = "Reviewed";
                submission.Grade = request.Grade;
            }
            submission.Remarks = request.Remarks;

            await _context.SaveChangesAsync();
            
            // Notify Student
            var assignment = await _context.Assignments.FindAsync(submission.AssignmentId);
            var assignmentTitle = assignment?.Title ?? "Unknown Assignment";

            // Notify Student
            _context.Notifications.Add(new Notification
            {
                UserId = submission.StudentId, 
                Message = $"Your submission for assignment {assignmentTitle} has been {(request.Rejected ? "REJECTED" : "REVIEWED")}",
                CreatedAt = DateTime.UtcNow
            });
            await _context.SaveChangesAsync();

            return Ok("Submission graded.");
        }
    }
}
