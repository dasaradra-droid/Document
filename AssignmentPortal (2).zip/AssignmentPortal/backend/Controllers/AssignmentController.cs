using AssignmentPortal.Backend.Data;
using AssignmentPortal.Backend.DTOs;
using AssignmentPortal.Backend.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace AssignmentPortal.Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class AssignmentController : ControllerBase
    {
        private readonly AppDbContext _context;

        public AssignmentController(AppDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        [Authorize(Roles = "Teacher")]
        public async Task<IActionResult> CreateAssignment(AssignmentCreateDto request)
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value);

            var assignment = new Assignment
            {
                Title = request.Title,
                Description = request.Description,
                Deadline = request.Deadline,
                TeacherId = userId
            };

            _context.Assignments.Add(assignment);
            await _context.SaveChangesAsync();

            // Notify all students
            var students = await _context.Users.Where(u => u.Role == "Student").ToListAsync();
            var notifications = students.Select(s => new Notification
            {
                UserId = s.Id,
                Message = $"New Assignment Created: {assignment.Title}",
                CreatedAt = DateTime.UtcNow
            });
            _context.Notifications.AddRange(notifications);
            await _context.SaveChangesAsync();


            return Ok("Assignment created successfully.");
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<AssignmentDto>>> GetAssignments()
        {
            var assignments = await _context.Assignments
                .Include(a => a.Teacher)
                .Select(a => new AssignmentDto
                {
                    Id = a.Id,
                    Title = a.Title,
                    Description = a.Description,
                    Deadline = a.Deadline,
                    TeacherId = a.TeacherId,
                    TeacherName = a.Teacher.Username
                })
                .ToListAsync();

            return Ok(assignments);
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "Teacher")]
        public async Task<IActionResult> DeleteAssignment(int id)
        {
             var assignment = await _context.Assignments.FindAsync(id);
             if (assignment == null) return NotFound();

             _context.Assignments.Remove(assignment);
             await _context.SaveChangesAsync();
             return Ok("Deleted.");
        }
    }
}
