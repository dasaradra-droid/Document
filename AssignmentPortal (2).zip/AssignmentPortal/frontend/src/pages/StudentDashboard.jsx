import React, { useState, useEffect } from 'react';
import api from '../services/api';
import { toast } from 'react-toastify';
import { motion } from 'framer-motion';
import { useAuth } from '../context/AuthContext';

import NotificationBell from '../components/NotificationBell';

const StudentDashboard = () => {
    const { logout, user } = useAuth();
    const [assignments, setAssignments] = useState([]);
    const [submissions, setSubmissions] = useState([]); // My submissions
    const [uploading, setUploading] = useState(null); // ID of assignment being uploaded to

    useEffect(() => {
        fetchData();
    }, []);

    const fetchData = async () => {
        // Fetch Assignments
        try {
            const res = await api.get('/assignment');
            setAssignments(res.data);
        } catch (err) {
            console.error("Assignments Error:", err);
            toast.error("Failed to load assignments: " + (err.response?.data || err.message));
        }

        // Fetch Submissions
        try {
            const res = await api.get('/submission/my-submissions');
            setSubmissions(res.data);
        } catch (err) {
            console.error("Submissions Error:", err);
            toast.error("Failed to load submissions: " + (err.response?.data || err.message));
        }
    };

    const handleUpload = async (assignmentId, file) => {
        if (!file) return;

        const formData = new FormData();
        formData.append('file', file);

        setUploading(assignmentId);
        try {
            await api.post(`/submission/${assignmentId}`, formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });
            toast.success("Assignment Submitted!");
            fetchData();
        } catch (err) {
            console.error(err);
            toast.error(err.response?.data || "Upload failed");
        } finally {
            setUploading(null);
        }
    };

    const getSubmission = (assignmentId) => submissions.find(s => s.assignmentId === assignmentId);

    return (
        <div className="container" style={{ padding: '2rem 1rem' }}>
            <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '3rem', borderBottom: '1px solid #e5e7eb', paddingBottom: '1rem' }}>
                <div style={{ display: 'flex', flexDirection: 'column' }}>
                    <h2 style={{ fontSize: '1rem', fontWeight: '800', color: 'var(--primary)', letterSpacing: '1px', textTransform: 'uppercase', marginBottom: '0.25rem' }}>Assignment Submission Portal</h2>
                    <h1 style={{ fontSize: '1.8rem', fontWeight: 'bold', color: '#1f2937' }}>Student Dashboard</h1>
                </div>

                <div style={{ display: 'flex', gap: '1.5rem', alignItems: 'center' }}>
                    <NotificationBell />
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                        <div style={{ textAlign: 'right' }}>
                            <span style={{ display: 'block', fontSize: '0.85rem', color: '#6b7280' }}>Welcome back,</span>
                            <span style={{ fontWeight: '700', color: '#111827', fontSize: '1.1rem' }}>Hello, {user.unique_name}</span>
                        </div>
                        <div style={{ width: '40px', height: '40px', background: 'var(--primary)', color: 'white', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 'bold' }}>
                            {user.unique_name.charAt(0).toUpperCase()}
                        </div>
                    </div>
                    <button onClick={logout} className="btn" style={{ background: '#f3f4f6', color: '#374151', padding: '0.5rem 1.25rem' }}>Logout</button>
                </div>
            </header>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '1.5rem' }}>
                {assignments.map(assign => {
                    const submission = getSubmission(assign.id);
                    const isSubmitted = !!submission;

                    return (
                        <motion.div
                            key={assign.id}
                            layout
                            className="card"
                            whileHover={{ y: -5 }}
                        >
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start' }}>
                                <h3 style={{ fontSize: '1.25rem', fontWeight: 'bold' }}>{assign.title}</h3>
                                {isSubmitted && (
                                    <span style={{
                                        padding: '0.25rem 0.5rem', borderRadius: '999px', fontSize: '0.75rem', fontWeight: 'bold',
                                        background: submission.status === 'Rejected' ? '#fee2e2' : '#d1fae5',
                                        color: submission.status === 'Rejected' ? '#b91c1c' : '#065f46'
                                    }}>
                                        {submission.status}
                                    </span>
                                )}
                            </div>
                            <p style={{ color: 'var(--text-light)', margin: '0.5rem 0' }}>{assign.description}</p>
                            <div style={{ fontSize: '0.875rem', color: 'var(--text-light)', marginBottom: '1rem' }}>
                                Deadline: {new Date(assign.deadline).toLocaleDateString()}
                                <br />
                                Teacher: {assign.teacherName}
                            </div>

                            {isSubmitted ? (
                                <div style={{ background: '#f9fafb', padding: '0.5rem', borderRadius: '8px' }}>
                                    <p style={{ fontSize: '0.9rem' }}>Submitted on {new Date(submission.submittedAt).toLocaleDateString()}</p>
                                    {submission.grade && <p style={{ fontWeight: 'bold', color: 'var(--primary)' }}>Grade: {submission.grade}</p>}
                                    {submission.remarks && <p style={{ fontSize: '0.85rem' }}>Remarks: {submission.remarks}</p>}
                                </div>
                            ) : (
                                <div style={{ marginTop: '1rem' }}>
                                    <label className="btn btn-primary" style={{ width: '100%', cursor: uploading === assign.id ? 'wait' : 'pointer' }}>
                                        {uploading === assign.id ? 'Uploading...' : 'Upload Assignment'}
                                        <input
                                            type="file"
                                            hidden
                                            onChange={(e) => handleUpload(assign.id, e.target.files[0])}
                                            disabled={uploading === assign.id}
                                        />
                                    </label>
                                </div>
                            )}
                        </motion.div>
                    );
                })}
            </div>
        </div>
    );
};

export default StudentDashboard;
