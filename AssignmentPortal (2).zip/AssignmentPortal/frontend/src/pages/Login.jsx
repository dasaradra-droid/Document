import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate, Link } from 'react-router-dom';
import { toast } from 'react-toastify';
import { motion } from 'framer-motion';
import { FaEye, FaEyeSlash } from 'react-icons/fa';

import loginImage from '../Image/1.jpg'; // Verify path case sensitivity

const Login = () => {
    const [formData, setFormData] = useState({ username: '', password: '' });
    const [showPassword, setShowPassword] = useState(false);
    const { login } = useAuth();
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        const result = await login(formData.username, formData.password);
        if (result.success) {
            toast.success("Welcome back!");
            navigate('/dashboard');
        } else {
            toast.error(result.message);
        }
    };

    return (
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', width: '100vw', overflow: 'hidden', background: '#f3f4f6', padding: '1rem' }}>
            <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                style={{
                    display: 'flex',
                    width: '100%',
                    maxWidth: '1000px',
                    maxHeight: '95vh',
                    overflowY: 'auto',
                    background: 'white',
                    borderRadius: '24px',
                    overflow: 'hidden',
                    boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)'
                }}
            >
                {/* Left Side - Form */}
                <div style={{ flex: 1, padding: '2rem', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                    <h1 style={{
                        color: 'var(--primary)',
                        fontSize: '1.75rem',
                        fontWeight: '800',
                        marginBottom: '0.25rem',
                        lineHeight: 1.2
                    }}>
                        ASSIGNMENT SUBMISSION PORTAL
                    </h1>
                    <p style={{ color: '#6b7280', marginBottom: '1.5rem', fontSize: '0.9rem' }}>Welcome back! Please login to your account.</p>

                    <h2 style={{ fontSize: '1.5rem', fontWeight: 'bold', marginBottom: '1rem', color: '#1f2937' }}>Sign In</h2>

                    <form onSubmit={handleSubmit}>
                        <div className="form-group" style={{ marginBottom: '0.75rem' }}>
                            <label style={{ display: 'block', marginBottom: '0.25rem', fontSize: '0.875rem', fontWeight: '600', color: '#374151' }}>Username or Email</label>
                            <input
                                type="text"
                                className="input-field"
                                placeholder="Enter your username or email"
                                value={formData.username}
                                onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                                required
                                style={{ marginBottom: 0, padding: '0.6rem' }}
                            />
                        </div>
                        <div className="form-group" style={{ position: 'relative', marginBottom: '1.25rem' }}>
                            <label style={{ display: 'block', marginBottom: '0.25rem', fontSize: '0.875rem', fontWeight: '600', color: '#374151' }}>Password</label>
                            <input
                                type={showPassword ? "text" : "password"}
                                className="input-field"
                                placeholder="Enter your password"
                                value={formData.password}
                                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                                required
                                style={{ marginBottom: 0, paddingRight: '2.5rem', padding: '0.6rem' }}
                            />
                            <span
                                onClick={() => setShowPassword(!showPassword)}
                                style={{
                                    position: 'absolute',
                                    right: '12px',
                                    top: '32px', // Adjusted for label height and padding
                                    cursor: 'pointer',
                                    color: '#6b7280',
                                    fontSize: '1.1rem'
                                }}
                            >
                                {showPassword ? <FaEyeSlash /> : <FaEye />}
                            </span>
                        </div>
                        <button type="submit" className="btn btn-primary" style={{ width: '100%', fontSize: '1rem', padding: '0.75rem' }}>
                            Sign In
                        </button>
                    </form>
                    <p style={{ textAlign: 'center', marginTop: '1rem', color: '#6b7280', fontSize: '0.9rem' }}>
                        Don't have an account? <Link to="/signup" style={{ color: 'var(--primary)', fontWeight: '600' }}>Sign Up</Link>
                    </p>
                </div>
                {/* Right Side - Image */}
                <div className="desktop-only" style={{ flex: 1 }}>
                    <div style={{
                        height: '100%',
                        width: '100%',
                        backgroundImage: `url(${loginImage})`,
                        backgroundSize: '100% 100%',
                        backgroundPosition: 'center'
                    }} />
                </div>
                {/* CSS Media query equivalent inline styles for responsiveness are tricky in pure inline. 
                    I'll force flex for now as desktop view is priority, but add a style block for responsiveness if needed. 
                    Actually, let's keep it simple. If screen is small, flex-wrap will help? 
                    I will set a min-width for the image div or hide it on mobile via a helper class if 'md' prop doesn't work (which it won't here, this isn't Chakra UI).
                    I'll use a simple style object for the image container.
                */}
            </motion.div>

            <style>{`
                @media (max-width: 768px) {
                    .card > div:last-child {
                        display: none !important;
                    }
                }
            `}</style>
        </div>
    );
};

export default Login;
