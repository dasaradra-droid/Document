# Assignment Portal Setup Guide

This guide explains how to set up and run the Assignment Portal on a new Windows machine.

## Prerequisites
Before you begin, ensure the new system has the following installed:
1.  **Node.js**: [Download LTS Version](https://nodejs.org/) (Required for Frontend)
2.  **.NET SDK**: [Download .NET 8 SDK](https://dotnet.microsoft.com/en-us/download) (Required for Backend)
3.  **SQL Server Express** (or any SQL Server instance): [Download](https://www.microsoft.com/en-us/sql-server/sql-server-downloads)
4.  **SQL Server Management Studio (SSMS)** (Optional, for viewing the DB): [Download](https://learn.microsoft.com/en-us/sql/ssms/download-sql-server-management-studio-ssms)

---

## 1. Backend Setup (API)

### Step 1: Configure Database
1.  Open `backend/appsettings.json`.
2.  Find the `ConnectionStrings` section:
    ```json
    "ConnectionStrings": {
      "DefaultConnection": "Server=YOUR_SERVER_NAME;Database=AssignmentPortalDb;Trusted_Connection=True;TrustServerCertificate=True;"
    }
    ```
3.  **Important**: Change `Server=LAPTOP-GCGD04CK\\SQLEXPRESS` to the server name of the *new* machine.
    *   You can find this by opening SSMS or running `hostname` in the command prompt (usually it's `(localdb)\mssqllocaldb` or `.\SQLEXPRESS`).

### Step 2: Database Migrations
You have two options for setting up the database:

**Option A: Standard (Keep existing migration history)**
*Use this if you want to keep the exact schema history.*
1.  Open a terminal in the `backend` folder.
2.  Run the command:
    ```powershell
    dotnet ef database update
    ```

**Option B: Fresh Start (Recommended for new setup)**
*Use this if you want a clean slate or run into migration errors.*
1.  **Delete** the `Migrations` folder inside the `backend` directory.
2.  Open a terminal in the `backend` folder.
3.  Run these commands:
    ```powershell
    dotnet ef migrations add InitialCreate
    dotnet ef database update
    ```
    *This creates a fresh database schema based on the current code.*

### Step 3: Run the Backend
1.  In the `backend` terminal, run:
    ```powershell
    dotnet run
    ```
2.  The server should start (usually at `http://localhost:5000`).

---

## 2. Frontend Setup (React App)

1.  Open a new terminal in the `frontend` folder.
2.  Install dependencies:
    ```powershell
    npm install
    ```
3.  Start the development server:
    ```powershell
    npm run dev
    ```
4.  Open the link shown (usually `http://localhost:5173`) in your browser.

---

## checklist for Sharing
If you are sending this code to someone else, make sure to:
1.  **Remove `node_modules`**: Delete the `frontend/node_modules` folder before zipping (it's huge and can be re-installed).
2.  **Remove `bin` and `obj`**: Delete `backend/bin` and `backend/obj` folders (they contain compiled files specific to your machine).
3.  **Security Warning**: Your `appsettings.json` contains AWS keys. **Do not share real sensitive keys publicly.** If this is for a production app, use Environment Variables instead.

---

## Dependency Reference
You **do not** need to install these manually. The commands `npm install` (Frontend) and `dotnet run` (Backend) automatically install them for you based on the configuration files.

### Frontend (Node Modules)
These are listed in `package.json` and served by `node_modules`:
*   **Core**: `react`, `react-dom`, `react-router-dom`
*   **Styling & UI**: `framer-motion`, `react-icons`, `react-toastify`
*   **Utilities**: `axios` (API calls), `jwt-decode` (Auth)

### Backend (NuGet Packages)
These are listed in the `.csproj` file and managed by .NET:
*   **Database**: `Microsoft.EntityFrameworkCore.SqlServer`, `Microsoft.EntityFrameworkCore.Tools`
*   **Auth**: `Microsoft.AspNetCore.Authentication.JwtBearer`, `BCrypt.Net-Next`
*   **Storage**: `AWSSDK.S3`
*   **Docs**: `Swashbuckle.AspNetCore` (Swagger UI)
