# Assignment Portal

A full-stack assignment submission portal with Role-Based Access Control, built with ASP.NET Web API and React.js.

## Prerequisites
- .NET 8.0 SDK
- Node.js & npm
- SQL Server (LocalDB or Express)
- AWS S3 Credentials

## Project Structure
- `backend/`: ASP.NET Core Web API
- `frontend/`: React + Vite

## How to Run

### 1. Backend (API)
The backend runs on port `5000`.
```bash
cd backend
dotnet run --urls=http://localhost:5000
```
Swagger Documentation: [http://localhost:5000/swagger](http://localhost:5000/swagger)

### 2. Frontend (UI)
The frontend runs on port `5173`.
```bash
cd frontend
npm run dev
```
Access the App: [http://localhost:5173](http://localhost:5173)

## Features
- **Teacher**: Create assignments, download submissions, grade/reject.
- **Student**: View assignments, upload files to S3, view grades.
- **Real-time**: Notification updates for submissions and grading.
