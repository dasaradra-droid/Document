import React, { useState, useEffect, useRef } from 'react';
import { FaBell } from 'react-icons/fa';
import api from '../services/api';
import { motion, AnimatePresence } from 'framer-motion';

const NotificationBell = () => {
    const [notifications, setNotifications] = useState([]);
    const [showDropdown, setShowDropdown] = useState(false);
    const dropdownRef = useRef(null);

    const unreadCount = notifications.filter(n => !n.isRead).length;

    const fetchNotifications = async () => {
        try {
            const res = await api.get('/notification');
            setNotifications(res.data);
        } catch (err) {
            console.error("Failed to fetch notifications", err);
        }
    };

    useEffect(() => {
        fetchNotifications();
        const interval = setInterval(fetchNotifications, 30000); // Poll every 30s
        return () => clearInterval(interval);
    }, []);

    // Close dropdown on click outside
    useEffect(() => {
        const handleClickOutside = (event) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
                setShowDropdown(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, [dropdownRef]);

    const markAsRead = async (id) => {
        try {
            await api.put(`/notification/${id}/read`); // Use PUT as defined in backend? Wait, check backend again.
            // Optimistic update
            setNotifications(notifications.map(n => n.id === id ? { ...n, isRead: true } : n));
        } catch (err) {
            console.error(err);
        }
    };
    // Check backend controller method for markAsRead.
    // It was [HttpPut("{id}/read")] in my thought but let me double check the file content trace.
    // File content trace: [HttpPost("mark-read/{id}")]
    // AH! It is POST mark-read/{id}.  FIX THIS.

    const handleBellClick = () => {
        if (!showDropdown && unreadCount > 0) {
            // Mark all currently loaded notifications as read locally to clear dot immediately
            // And trigger backend updates silently
            const unreadIds = notifications.filter(n => !n.isRead).map(n => n.id);
            setNotifications(notifications.map(n => ({ ...n, isRead: true })));

            unreadIds.forEach(async (id) => {
                try {
                    await api.post(`/notification/mark-read/${id}`);
                } catch (err) {
                    console.error("Failed to mark read", err);
                }
            });
        }
        setShowDropdown(!showDropdown);
    };

    const markReadClick = async (n) => {
        if (n.isRead) return;
        try {
            await api.post(`/notification/mark-read/${n.id}`);
            setNotifications(prev => prev.map(item => item.id === n.id ? { ...item, isRead: true } : item));
        } catch (err) {
            console.error("Failed to mark read", err);
        }
    };

    return (
        <div className="notification-container" style={{ position: 'relative' }} ref={dropdownRef}>
            <div
                onClick={handleBellClick}
                style={{ position: 'relative', cursor: 'pointer', padding: '0.5rem', borderRadius: '50%', background: '#fff', boxShadow: '0 2px 5px rgba(0,0,0,0.05)' }}
            >
                <FaBell style={{ fontSize: '1.2rem', color: '#6b7280' }} />
                {unreadCount > 0 && (
                    <span style={{
                        position: 'absolute', top: '2px', right: '4px',
                        background: '#ef4444',
                        borderRadius: '50%',
                        width: '10px', height: '10px',
                        border: '2px solid white'
                    }}>
                    </span>
                )}
            </div>

            <AnimatePresence>
                {showDropdown && (
                    <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 10 }}
                        style={{
                            position: 'absolute',
                            top: '120%',
                            right: 0,
                            width: '320px',
                            maxHeight: '400px',
                            overflowY: 'auto',
                            background: 'white',
                            borderRadius: '12px',
                            boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.5)',
                            zIndex: 1000,
                            border: '1px solid #f3f4f6'
                        }}
                    >
                        <div style={{ padding: '1rem', borderBottom: '1px solid #f3f4f6', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <h3 style={{ fontSize: '0.9rem', fontWeight: 'bold', color: '#1f2937', margin: 0 }}>Notifications</h3>
                            <div style={{ display: 'flex', gap: '0.5rem' }}>
                                <button onClick={async () => {
                                    try {
                                        await api.delete('/notification');
                                        setNotifications([]);
                                    } catch (err) { console.error(err); }
                                }} style={{ background: 'none', border: 'none', color: '#ef4444', fontSize: '0.8rem', cursor: 'pointer' }}>Clear All</button>
                                <button onClick={fetchNotifications} style={{ background: 'none', border: 'none', color: 'var(--primary)', fontSize: '0.8rem', cursor: 'pointer' }}>Refresh</button>
                            </div>
                        </div>

                        <div style={{ display: 'flex', flexDirection: 'column' }}>
                            {notifications.length === 0 ? (
                                <p style={{ padding: '2rem', textAlign: 'center', color: '#9ca3af', fontSize: '0.9rem' }}>No notifications</p>
                            ) : (
                                notifications.map(n => (
                                    <div
                                        key={n.id}
                                        onClick={() => markReadClick(n)}
                                        style={{
                                            padding: '1rem',
                                            borderBottom: '1px solid #f9fafb',
                                            background: n.isRead ? 'white' : '#f0f9ff',
                                            cursor: 'pointer',
                                            transition: 'background 0.2s'
                                        }}
                                        onMouseEnter={(e) => e.currentTarget.style.background = n.isRead ? '#f9fafb' : '#e0f2fe'}
                                        onMouseLeave={(e) => e.currentTarget.style.background = n.isRead ? 'white' : '#f0f9ff'}
                                    >
                                        <p style={{ fontSize: '0.85rem', color: '#374151', marginBottom: '0.25rem', lineHeight: '1.4' }}>{n.message}</p>
                                        <span style={{ fontSize: '0.75rem', color: '#9ca3af' }}>
                                            {new Date(n.createdAt).toLocaleString()}
                                        </span>
                                    </div>
                                ))
                            )}
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
};

export default NotificationBell;
