import React, { useState, useEffect } from 'react';
import api from '../services/api';
import { toast } from 'react-toastify';
import { motion } from 'framer-motion';
import { useAuth } from '../context/AuthContext';

import NotificationBell from '../components/NotificationBell';

const TeacherDashboard = () => {
    const { logout, user } = useAuth();
    const [assignments, setAssignments] = useState([]);
    const [showCreateModal, setShowCreateModal] = useState(false);
    const [newAssignment, setNewAssignment] = useState({ title: '', description: '', deadline: '' });
    const [selectedAssignment, setSelectedAssignment] = useState(null); // To view submissions

    useEffect(() => {
        fetchAssignments();
    }, []);

    const fetchAssignments = async () => {
        try {
            const res = await api.get('/assignment');
            setAssignments(res.data);
        } catch (err) {
            toast.error("Failed to fetch assignments");
        }
    };

    const handleCreate = async (e) => {
        e.preventDefault();
        try {
            await api.post('/assignment', newAssignment);
            toast.success("Assignment created!");
            setShowCreateModal(false);
            fetchAssignments();
        } catch (err) {
            toast.error("Failed to create");
        }
    };

    const handleDelete = async (id) => {
        if (window.confirm("Are you sure you want to delete this assignment?")) {
            try {
                await api.delete(`/assignment/${id}`);
                toast.success("Assignment deleted");
                fetchAssignments();
            } catch (err) {
                toast.error("Failed to delete assignment");
            }
        }
    };

    return (
        <div className="container" style={{ padding: '2rem 1rem' }}>
            <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '3rem', borderBottom: '1px solid #e5e7eb', paddingBottom: '1rem' }}>
                <div style={{ display: 'flex', flexDirection: 'column' }}>
                    <h2 style={{ fontSize: '1rem', fontWeight: '800', color: 'var(--primary)', letterSpacing: '1px', textTransform: 'uppercase', marginBottom: '0.25rem' }}>Assignment Submission Portal</h2>
                    <h1 style={{ fontSize: '1.8rem', fontWeight: 'bold', color: '#1f2937' }}>Teacher Dashboard</h1>
                </div>

                <div style={{ display: 'flex', gap: '1.5rem', alignItems: 'center' }}>
                    <NotificationBell />
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                        <div style={{ textAlign: 'right' }}>
                            <span style={{ display: 'block', fontSize: '0.85rem', color: '#6b7280' }}>Welcome back,</span>
                            <span style={{ fontWeight: '700', color: '#111827', fontSize: '1.1rem' }}>Hello, {user.unique_name}</span>
                        </div>
                        <div style={{ width: '40px', height: '40px', background: 'var(--primary)', color: 'white', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 'bold' }}>
                            {user.unique_name.charAt(0).toUpperCase()}
                        </div>
                    </div>
                    <button onClick={logout} className="btn" style={{ background: '#f3f4f6', color: '#374151', padding: '0.5rem 1.25rem' }}>Logout</button>
                </div>
            </header>

            <button onClick={() => setShowCreateModal(true)} className="btn btn-primary" style={{ marginBottom: '1rem' }}>
                + Create Assignment
            </button>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '1.5rem' }}>
                {assignments.map(assign => (
                    <motion.div
                        key={assign.id}
                        layout
                        className="card"
                        whileHover={{ y: -5 }}
                    >
                        <h3 style={{ fontSize: '1.25rem', fontWeight: 'bold', marginBottom: '0.5rem' }}>{assign.title}</h3>
                        <p style={{ color: 'var(--text-light)', marginBottom: '1rem' }}>{assign.description}</p>
                        <p style={{ fontSize: '0.875rem', marginBottom: '1rem' }}>Deadline: {new Date(assign.deadline).toLocaleDateString()}</p>
                        <div style={{ display: 'flex', gap: '0.5rem' }}>
                            <button className="btn" style={{ background: '#f3f4f6', color: 'var(--primary)', flex: 1 }} onClick={() => setSelectedAssignment(assign)}>
                                View Submissions
                            </button>
                            <button className="btn" style={{ background: '#fee2e2', color: '#dc2626', flex: 1 }} onClick={() => handleDelete(assign.id)}>
                                Delete
                            </button>
                        </div>
                    </motion.div>
                ))}
            </div>

            {showCreateModal && (
                <div style={{
                    position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
                    background: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center'
                }}>
                    <div className="card" style={{ width: '400px', maxWidth: '90%' }}>
                        <h3>Create Assignment</h3>
                        <form onSubmit={handleCreate} style={{ marginTop: '1rem' }}>
                            <input className="input-field" placeholder="Title" required
                                value={newAssignment.title} onChange={e => setNewAssignment({ ...newAssignment, title: e.target.value })} />
                            <textarea className="input-field" placeholder="Description" rows="3"
                                value={newAssignment.description} onChange={e => setNewAssignment({ ...newAssignment, description: e.target.value })} />
                            <input className="input-field" type="date" required
                                value={newAssignment.deadline} onChange={e => setNewAssignment({ ...newAssignment, deadline: e.target.value })} />
                            <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem' }}>
                                <button type="button" onClick={() => setShowCreateModal(false)} className="btn" style={{ flex: 1, background: '#e5e7eb' }}>Cancel</button>
                                <button type="submit" className="btn btn-primary" style={{ flex: 1 }}>Create</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {selectedAssignment && (
                <SubmissionsModal assignment={selectedAssignment} onClose={() => setSelectedAssignment(null)} />
            )}
        </div>
    );
};

const SubmissionsModal = ({ assignment, onClose }) => {
    const [submissions, setSubmissions] = useState([]);

    useEffect(() => {
        // Fetch submissions
        api.get(`/submission/assignment/${assignment.id}`).then(res => setSubmissions(res.data));
    }, [assignment.id]);

    const handleDownload = (url) => {
        window.open(url, '_blank');
    };

    const handleGrade = async (id, grade, remarks, rejected) => {
        try {
            await api.post(`/submission/${id}/grade`, { grade, remarks, rejected });
            toast.success(rejected ? "Rejected" : "Graded");
            // refresh
            const res = await api.get(`/submission/assignment/${assignment.id}`);
            setSubmissions(res.data);
        } catch {
            toast.error("Failed to grade");
        }
    };

    return (
        <div style={{
            position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
            background: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 50
        }}>
            <div className="card" style={{ width: '900px', maxWidth: '95%', maxHeight: '90vh', overflowY: 'auto' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem' }}>
                    <h3>Submissions for {assignment.title}</h3>
                    <button onClick={onClose} style={{ background: 'none', fontSize: '1.5rem' }}>&times;</button>
                </div>
                <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                    <thead>
                        <tr style={{ textAlign: 'left', borderBottom: '1px solid #e5e7eb' }}>
                            <th style={{ padding: '0.5rem' }}>Student</th>
                            <th style={{ padding: '0.5rem' }}>Date</th>
                            <th style={{ padding: '0.5rem' }}>Status</th>
                            <th style={{ padding: '0.5rem' }}>Grade</th>
                            <th style={{ padding: '0.5rem' }}>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {submissions.map(sub => (
                            <SubmissionRow key={sub.id} sub={sub} onGrade={handleGrade} onDownload={handleDownload} />
                        ))}
                        {submissions.length === 0 && <tr><td colSpan="5" style={{ padding: '1rem', textAlign: 'center' }}>No submissions yet</td></tr>}
                    </tbody>
                </table>
            </div>
        </div>
    );
}

const SubmissionRow = ({ sub, onGrade, onDownload }) => {
    const [remark, setRemark] = useState('');
    const [grade, setGrade] = useState('');

    const handleSubmit = () => {
        if (!grade) {
            toast.error("Please select a grade first.");
            return;
        }

        if (grade === 'Reject') {
            onGrade(sub.id, null, remark || 'Rejected by Teacher', true);
        } else {
            onGrade(sub.id, grade, remark || 'Good', false);
        }
    };

    return (
        <tr style={{ borderBottom: '1px solid #f3f4f6' }}>
            <td style={{ padding: '0.5rem' }}>{sub.studentName}</td>
            <td style={{ padding: '0.5rem' }}>{new Date(sub.submittedAt).toLocaleDateString()}</td>
            <td style={{ padding: '0.5rem' }}>{sub.status}</td>
            <td style={{ padding: '0.5rem' }}>{sub.grade || '-'}</td>
            <td style={{ padding: '0.5rem', display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
                <button onClick={() => onDownload(sub.fileUrl)} className="btn" style={{ padding: '0.25rem 0.5rem', fontSize: '0.8rem', background: '#dbeafe', color: '#1e40af' }}>Download</button>
                {sub.status === 'Submitted' && (
                    <div style={{ display: 'flex', gap: '0.25rem', alignItems: 'center' }}>
                        <input
                            className="input-field"
                            type="text"
                            placeholder="Remark..."
                            value={remark}
                            onChange={(e) => setRemark(e.target.value)}
                            style={{ padding: '0.3rem', fontSize: '0.8rem', width: '120px', marginBottom: 0 }}
                        />
                        <select
                            value={grade}
                            onChange={(e) => setGrade(e.target.value)}
                            style={{ padding: '0.25rem', borderRadius: '4px', border: '1px solid #d1d5db' }}
                        >
                            <option value="">Select Grade</option>
                            <option value="A">Grade A</option>
                            <option value="B">Grade B</option>
                            <option value="C">Grade C</option>
                            <option value="D">Grade D</option>
                            <option value="E">Grade E</option>
                            <option value="Reject">Reject</option>
                        </select>
                        <button
                            onClick={handleSubmit}
                            className="btn btn-primary"
                            style={{ padding: '0.25rem 0.5rem', fontSize: '0.8rem' }}
                        >
                            Submit
                        </button>
                    </div>
                )}
            </td>
        </tr>
    );
};

export default TeacherDashboard;
