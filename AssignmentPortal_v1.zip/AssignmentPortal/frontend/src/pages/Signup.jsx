import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate, Link } from 'react-router-dom';
import { toast } from 'react-toastify';
import { motion } from 'framer-motion';
import { FaEye, FaEyeSlash } from 'react-icons/fa';

import loginImage from '../Image/1.jpg';

const Signup = () => {
    const [formData, setFormData] = useState({ username: '', email: '', password: '', role: 'Student' });
    const [showPassword, setShowPassword] = useState(false);
    const { register } = useAuth();
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        const result = await register(formData);
        if (result.success) {
            toast.success("Account created! Please login.");
            navigate('/login');
        } else {
            toast.error(result.message);
        }
    };

    return (
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', width: '100vw', overflow: 'hidden', background: '#f3f4f6', padding: '1rem' }}>
            <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                style={{
                    display: 'flex',
                    width: '100%',
                    maxWidth: '1000px',
                    maxHeight: '95vh',
                    overflowY: 'auto',
                    background: 'white',
                    borderRadius: '24px',
                    overflow: 'hidden',
                    boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)'
                }}
            >
                {/* Left Side - Form */}
                <div style={{ flex: 1, padding: '2rem', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                    <h2 style={{ fontSize: '1.75rem', fontWeight: 'bold', marginBottom: '0.25rem', color: '#1f2937' }}>Create Account</h2>
                    <p style={{ color: '#6b7280', marginBottom: '1.5rem', fontSize: '0.9rem' }}>Join us! Please enter your details.</p>

                    <form onSubmit={handleSubmit}>
                        <div className="form-group" style={{ marginBottom: '0.75rem' }}>
                            <label style={{ display: 'block', marginBottom: '0.25rem', fontSize: '0.875rem', fontWeight: '600', color: '#374151' }}>Username</label>
                            <input
                                type="text"
                                className="input-field"
                                placeholder="Choose a username"
                                value={formData.username}
                                onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                                required
                                style={{ marginBottom: 0, padding: '0.6rem' }}
                            />
                        </div>
                        <div className="form-group" style={{ marginBottom: '0.75rem' }}>
                            <label style={{ display: 'block', marginBottom: '0.25rem', fontSize: '0.875rem', fontWeight: '6.00', color: '#374151' }}>Email</label>
                            <input
                                type="email"
                                className="input-field"
                                placeholder="Enter your email"
                                value={formData.email}
                                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                                required
                                style={{ marginBottom: 0, padding: '0.6rem' }}
                            />
                        </div>
                        <div className="form-group" style={{ position: 'relative', marginBottom: '0.75rem' }}>
                            <label style={{ display: 'block', marginBottom: '0.25rem', fontSize: '0.875rem', fontWeight: '600', color: '#374151' }}>Password</label>
                            <input
                                type={showPassword ? "text" : "password"}
                                className="input-field"
                                placeholder="Create a password"
                                value={formData.password}
                                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                                required
                                style={{ marginBottom: 0, paddingRight: '2.5rem', padding: '0.6rem' }}
                            />
                            <span
                                onClick={() => setShowPassword(!showPassword)}
                                style={{
                                    position: 'absolute',
                                    right: '12px',
                                    top: '32px',
                                    cursor: 'pointer',
                                    color: '#6b7280',
                                    fontSize: '1.1rem'
                                }}
                            >
                                {showPassword ? <FaEyeSlash /> : <FaEye />}
                            </span>
                        </div>
                        <div className="form-group" style={{ marginBottom: '1.25rem' }}>
                            <label style={{ display: 'block', marginBottom: '0.25rem', fontSize: '0.875rem', fontWeight: '600', color: '#374151' }}>I am a...</label>
                            <select
                                className="input-field"
                                value={formData.role}
                                onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                                style={{ marginBottom: 0, padding: '0.6rem' }}
                            >
                                <option value="Student">Student</option>
                                <option value="Teacher">Teacher</option>
                            </select>
                        </div>
                        <button type="submit" className="btn btn-primary" style={{ width: '100%', fontSize: '1rem', padding: '0.75rem' }}>
                            Sign Up
                        </button>
                    </form>
                    <p style={{ textAlign: 'center', marginTop: '1rem', color: '#6b7280', fontSize: '0.9rem' }}>
                        Already have an account? <Link to="/login" style={{ color: 'var(--primary)', fontWeight: '600' }}>Login</Link>
                    </p>
                </div>

                {/* Right Side - Image */}
                <div className="desktop-only" style={{ flex: 1 }}>
                    <div style={{
                        height: '100%',
                        width: '100%',
                        backgroundImage: `url(${loginImage})`,
                        backgroundSize: '100% 100%',
                        backgroundPosition: 'center'
                    }} />
                </div>
                <style>{`
                    @media (max-width: 768px) {
                        .card > div:last-child {
                            display: none !important;
                        }
                    }
                `}</style>
            </motion.div>
        </div>
    );
};

export default Signup;
