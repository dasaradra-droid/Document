using System;
using System.ComponentModel.DataAnnotations;

namespace AssignmentPortal.Backend.DTOs
{
    public class SubmissionDto
    {
        public int Id { get; set; }
        public int AssignmentId { get; set; }
        public string StudentName { get; set; }
        public string FileUrl { get; set; }
        public DateTime SubmittedAt { get; set; }
        public string Status { get; set; }
        public string? Grade { get; set; }
        public string? Remarks { get; set; }
    }

    public class GradeSubmissionDto
    {
        public string? Grade { get; set; } // A, B, C, D, E
        public string Remarks { get; set; }
        public bool Rejected { get; set; } // If true, set status to Rejected
    }
}
